#include "IMUCombiner.hpp"

// No additional implementation needed in the .cpp file as everything is inlined in the header
